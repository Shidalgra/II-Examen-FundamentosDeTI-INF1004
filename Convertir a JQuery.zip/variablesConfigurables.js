//////////////////////////////////
// VariablesConfigurables.js
//////////////////////////////////

// Nombre del examen
const EXAM_NAME = "Examen final de Fundamentos de TI - INF1004";
document.getElementById("title").textContent = EXAM_NAME;

// Configuración general
const EXAM_DURATION_MINUTES = 165; // Cambiar a 180 u otro valor si se desea

// Claves de LocalStorage
const EXAM_STORAGE_KEY = "examData";
const EXAM_STATE_KEY = "examState";

// Seguridad
const ADMIN_PASSWORD = "Shoudymella1986*"; // Ctrl + Alt + P
const MAX_CLEAR_USES = 1;
const CLEAR_INTERVAL_DAYS = 1;

// Configuración del examen
//intentos
const MAX_ATTEMPTS = 3;

// cantidad de preguntas de marque con x y cuanto valen
const UNIQUE_QUESTIONS_COUNT = 3; //20
const UNIQUE_QUESTIONS_VALUE = "1 PTS";

// cantidad de preguntas de desarrollo y cuanto valen
const DEVELOPMENT_QUESTIONS_COUNT = 5;
const DEVELOPMENT_QUESTIONS_VALUE = "2 PTS";

// Prácticas
const PRACTICE_QUESTIONS_PAREO = 10;
// crucigrama
const PRACTICE_QUESTIONS_SOUP = 10;

// Código de acceso
const ACCESS_CODE = "1";