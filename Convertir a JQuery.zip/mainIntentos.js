//////////////////////////////////
//Main_Intentos.js
/////////////////////////////////
//VARIABLES GLOBALES
let intentoYaRestado = false; // Para evitar que se reste más de una vez
let devtoolsAbierto = false;
let devtoolsYaDetectado = false;

// VARIABLES PARA TRACKING DE TIEMPO
let questionStartTime = null;
let questionTimes = {};

// GESTIÓN DE INTENTOS
function obtenerIntentosRestantes() {
    const data = JSON.parse(localStorage.getItem(EXAM_STORAGE_KEY));
    return data?.intentosRestantes ?? MAX_ATTEMPTS;
}

// RESTAR INTENTO
function restarIntentoYGuardar() {
    if (intentoYaRestado) return;

    let data = JSON.parse(localStorage.getItem(EXAM_STORAGE_KEY)) || { intentosRestantes: MAX_ATTEMPTS };
    data.intentosRestantes = Math.max(0, (data.intentosRestantes ?? MAX_ATTEMPTS) - 1);
    localStorage.setItem(EXAM_STORAGE_KEY, JSON.stringify(data));

    // Sincronizar con examData para el PDF
    let examData = JSON.parse(localStorage.getItem("examData")) || {};
    examData.intentosRestantes = data.intentosRestantes;
    localStorage.setItem("examData", JSON.stringify(examData));

    intentoYaRestado = true;
}

// VERIFICAR INTENTOS
function verificarIntentos() {
    const intentosRestantes = obtenerIntentosRestantes();
    if (intentosRestantes <= 0) {
        Swal.fire({
            icon: 'error',
            title: 'Exámen bloqueado',
            text: 'Has agotado todos tus intentos.',
            confirmButtonText: 'Entendido',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                confirmButton: 'swal-instrucciones-confirm',
                icon: 'swal-instrucciones-icon',
                htmlContainer: 'swal-instrucciones-text'
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                localStorage.setItem("practicaFinalizada", "true");
                mostrarPantallaFinalizada();
            }
        });
    }
}

// MOSTRAR INTENTOS RESTANTES
function mostrarIntentosRestantes() {
    const data = JSON.parse(localStorage.getItem(EXAM_STORAGE_KEY)) || { intentosRestantes: MAX_ATTEMPTS };
    const restantes = data.intentosRestantes ?? MAX_ATTEMPTS;
    const span = document.getElementById("intentos-restantes");

    if (!span) return;

    span.textContent = restantes;

    if (restantes === 2) {
        span.style.color = "orange";
    } else if (restantes === 1) {
        span.style.color = "red";
    } else if (restantes === 0) {
        span.style.color = "gray";
    } else {
        span.style.color = "green";
    }
}

// ACTUALIZAR ACCESO POR INTENTOS
function actualizarAccesoPorIntentos() {
    const restantes = obtenerIntentosRestantes();
    const accessSection = document.getElementById("access-section");
    const accessContent = document.getElementById("access-content");
    const noAttemptsContent = document.getElementById("no-attempts-content");

    if (!accessSection) return;

    if (restantes <= 0) {
        accessSection.classList.add("no-attempts");
        accessContent.style.display = "none";
        noAttemptsContent.style.display = "block";
        document.getElementById("uniqueSelection").style.display = "none";
        document.getElementById("essay").style.display = "none";
    } else {
        accessSection.classList.remove("no-attempts");
        accessContent.style.display = "block";
        noAttemptsContent.style.display = "none";
    }
}

// CONTROL DE ACCESO POR INTENTOS
function controlarAccesoPorIntentos() {
    const restantes = obtenerIntentosRestantes();
    const inputCodigo = document.getElementById("accessInput");
    const instrucciones = document.getElementById("toggleInstructionsBtn");
    const btnIngresar = inputCodigo?.nextElementSibling;

    if (restantes <= 0) {
        if (inputCodigo) inputCodigo.disabled = true;
        if (btnIngresar) btnIngresar.disabled = true;
        if (instrucciones) instrucciones.disabled = true;
    } else {
        if (inputCodigo) inputCodigo.disabled = false;
        if (btnIngresar) btnIngresar.disabled = false;
        if (instrucciones) instrucciones.disabled = false;
    }
}

// CONTROL UNIFICADO DE SALIDA / TRAMPA
function manejarSalidaExamen(tipo, evento = null) {
    if (intentoYaRestado) return;

    restarIntentoYGuardar();
    mostrarIntentosRestantes();
    localStorage.setItem(EXAM_STATE_KEY, "perdido");

    if (tipo === "recarga" && evento) {
        const msg = "Si recarga o sale, perderá un intento.";
        evento.preventDefault();
        evento.returnValue = msg;
        return msg;
    }

    if (tipo === "cambioPestania") {
        Swal.fire({
            icon: 'warning',
            title: 'Atención',
            text: 'Has salido del exámen. Perdiste un intento.',
            confirmButtonText: 'Entendido',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                confirmButton: 'swal-instrucciones-confirm',
                icon: 'swal-instrucciones-icon',
                htmlContainer: 'swal-instrucciones-text'
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            }
        }).then(() => location.reload());
    }

    if (tipo === "devtools") {
        Swal.fire({
            icon: 'error',
            title: 'Acción no permitida',
            text: 'Se detectó manipulación (DevTools). Has perdido un intento.',
            confirmButtonText: 'Entendido',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                confirmButton: 'swal-instrucciones-confirm',
                icon: 'swal-instrucciones-icon',
                htmlContainer: 'swal-instrucciones-text'
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            }
        }).then(() => location.reload());
    }
}

window.addEventListener("beforeunload", function (e) {
    // Si está en pantalla finalizada Y ya descargó el PDF, no restar intento
    if (localStorage.getItem("pantallaFinalizadaActiva") === "true" && localStorage.getItem("pdfDescargado") === "true") {
        return;
    }
    // Marcar que se va a recargar para detectarlo después
    localStorage.setItem("paginaRecargada", "true");
    manejarSalidaExamen("recarga", e);
});

document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
        manejarSalidaExamen("cambioPestania");
    }
});


// DETECCIÓN CONFIABLE DE DEVTOOLS
function detectarDevtoolsConTiempo() {
    const umbral = 100; // milisegundos

    const antes = new Date();
    Function('debugger')(); // Ejecuta sin mostrar nada
    const despues = new Date();

    const diferencia = despues - antes;

    if (diferencia > umbral && !devtoolsYaDetectado) {
        devtoolsYaDetectado = true;

        Swal.fire({
            icon: 'error',
            title: 'DevTools detectado',
            html: `
                <p>Has abierto las herramientas de desarrollo (DevTools).</p>
                <p><strong>Se perderá un intento</strong> por esta acción.</p>
            `,
            confirmButtonText: 'Entendido',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                confirmButton: 'swal-instrucciones-confirm',
                icon: 'swal-instrucciones-icon',
                htmlContainer: 'swal-instrucciones-text'
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            }
        }).then(() => {
            manejarSalidaExamen("devtools"); // restar intento
            location.reload(); // recarga para bloquear el intento
        });
    }
}

// Llamar la detección cada 1.5 segundos
setInterval(detectarDevtoolsConTiempo, 1500);


// MOSTRAR/OCULTAR INSTRUCCIONES
const btn = document.getElementById("toggleInstructionsBtn");
const instructions = document.getElementById("instruction");
instructions.style.display = "none";

btn?.addEventListener("click", () => {
    if (instructions.style.display === "none") {
        instructions.style.display = "block";
        btn.innerText = "Ocultar Instrucciones";
    } else {
        instructions.style.display = "none";
        btn.innerText = "Ver Instrucciones";
    }
});

document.addEventListener("click", function (e) {
    const isInside = instructions.contains(e.target) || btn.contains(e.target);
    if (!isInside && instructions.style.display === "block") {
        Swal.fire({
            icon: 'info',
            title: 'Instrucciones ocultas',
            text: 'Se han ocultado automáticamente al interactuar fuera.',
            confirmButtonText: 'Entendido',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                confirmButton: 'swal-instrucciones-confirm',
                icon: 'swal-instrucciones-icon',
                htmlContainer: 'swal-instrucciones-text'
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            }
        });
        instructions.style.display = "none";
        btn.innerText = "Ver Instrucciones";
    }
});

// CHECKBOX DE CONSENTIMIENTO
document.addEventListener("DOMContentLoaded", function () {
    const checkbox = document.getElementById("agreeCheck");
    if (!checkbox) return;

    // --- Aquí agrego código para cargar el estado guardado ---
    let estado = JSON.parse(localStorage.getItem(EXAM_STORAGE_KEY)) || {};
    if (estado.instruccionesAceptadas) {
        checkbox.checked = true;
        checkbox.disabled = true;
        instructions.style.display = "none";
        btn.innerText = "Ver Instrucciones";
    }

    // Evento para guardar cuando el usuario acepte
    checkbox.addEventListener("change", function () {
        if (checkbox.checked) {
            Swal.fire({
                icon: 'info',
                title: 'Consentimiento registrado',
                text: 'Aceptaste las instrucciones. No se puede deshacer.',
                confirmButtonText: 'Aceptar',
                allowOutsideClick: false,
                allowEscapeKey: false,
                customClass: {
                    popup: 'swal-instrucciones',
                    title: 'swal-instrucciones-title',
                    confirmButton: 'swal-instrucciones-confirm',
                    icon: 'swal-instrucciones-icon',
                    htmlContainer: 'swal-instrucciones-text'
                },
                didOpen: () => {
                    const popup = document.querySelector('swal-instrucciones');
                    if (popup) {
                        popup.scrollTop = 0; // Forzar scroll arriba
                    }
                }
            }).then((result) => {
                if (result.isConfirmed || result.dismiss) {
                    checkbox.disabled = true;
                    instructions.style.display = "none";
                    btn.innerText = "Ver Instrucciones";

                    // **Se añde esto para que se guarde en el localStorage**
                    let estado = JSON.parse(localStorage.getItem(EXAM_STORAGE_KEY)) || {};
                    estado.instruccionesAceptadas = true;
                    estado.fechaAceptacion = new Date().toISOString();
                    localStorage.setItem(EXAM_STORAGE_KEY, JSON.stringify(estado));
                } else {
                    checkbox.checked = false;
                }
            });
        } else {
            checkbox.checked = true;
        }
    });
});

// BOTÓN SECRETO PARA ADMINISTRADOR
window.addEventListener("DOMContentLoaded", () => {
    const adminBtn = document.getElementById("admin-clear");
    adminBtn.style.display = "none";

    document.addEventListener("keydown", function (e) {
        if (e.ctrlKey && e.altKey && e.code === "KeyP") {
            const usedCount = parseInt(localStorage.getItem("clearButtonUses") || "0", 10);
            if (usedCount < MAX_CLEAR_USES) {
                adminBtn.style.display = "block";
            }
        }
    });

    adminBtn.addEventListener("click", () => {
        const lastClearDateStr = localStorage.getItem("lastClearDate");
        const now = new Date();

        if (lastClearDateStr) {
            const lastClearDate = new Date(lastClearDateStr);
            const diffTime = now - lastClearDate;
            const diffDays = diffTime / (1000 * 60 * 60 * 24);
            if (diffDays < 2) {
                Swal.fire({
                    icon: "info",
                    title: "Espera requerida",
                    text: "Este botón solo se puede usar cada 2 días.",
                    confirmButtonText: 'Aceptar',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        popup: 'swal-instrucciones',
                        title: 'swal-instrucciones-title',
                        confirmButton: 'swal-instrucciones-confirm',
                        icon: 'swal-instrucciones-icon',
                        htmlContainer: 'swal-instrucciones-text'
                    },
                    didOpen: () => {
                        const popup = document.querySelector('swal-instrucciones');
                        if (popup) {
                            popup.scrollTop = 0; // Forzar scroll arriba
                        }
                    }
                });
                return;
            }
        }

        Swal.fire({
            title: "Confirmación",
            input: "password",
            inputLabel: "Ingrese su clave de administrador",
            inputPlaceholder: "Contraseña",
            showCancelButton: true,
            confirmButtonText: "Borrar todo",
            cancelButtonText: "Cancelar",
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                input: 'swal-instrucciones-input',
                confirmButton: 'swal-instrucciones-confirm',
                cancelButton: 'swal-instrucciones-cancel',
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            },

            preConfirm: (password) => {
                if (password !== ADMIN_PASSWORD) {
                    Swal.showValidationMessage("❌ Contraseña incorrecta");
                }
                return password === ADMIN_PASSWORD;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                localStorage.clear();
                localStorage.setItem("lastClearDate", now.toISOString());
                let usedCount = parseInt(localStorage.getItem("clearButtonUses") || "0", 10);
                usedCount++;
                localStorage.setItem("clearButtonUses", usedCount.toString());
                localStorage.removeItem("pantallaFinalizadaActiva"); // Asegurar que se limpia
                localStorage.removeItem("pdfDescargado"); // Asegurar que se limpia
                adminBtn.style.display = "none";

                Swal.fire({
                    icon: "success",
                    title: "Datos borrados",
                    text: "Todo el progreso del exámen fue eliminado.",
                    confirmButtonText: 'Entendido',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    customClass: {
                        popup: 'swal-instrucciones',
                        title: 'swal-instrucciones-title',
                        confirmButton: 'swal-instrucciones-confirm',
                    },
                    didOpen: () => {
                        const popup = document.querySelector('swal-instrucciones');
                        if (popup) {
                            popup.scrollTop = 0; // Forzar scroll arriba
                        }
                    }
                }).then(() => location.reload());
            }
        });
    });
});

// INICIALIZACIÓN
window.onload = function () {
    // Detectar si el código cambió y mostrar instrucciones importantes
    if (localStorage.getItem("codigoCambiado") === "true") {
        localStorage.removeItem("codigoCambiado");
        mostrarInstruccionesImportantes();
    }
    // Detectar si hubo recarga y mostrar mensaje
    else if (localStorage.getItem("paginaRecargada") === "true") {
        localStorage.removeItem("paginaRecargada");
        document.getElementById("name-section").style.display = "none";
        Swal.fire({
            icon: 'warning',
            title: 'Página recargada',
            text: 'Has recargado la página. Perdiste un intento.',
            confirmButtonText: 'Entendido',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'swal-instrucciones',
                title: 'swal-instrucciones-title',
                confirmButton: 'swal-instrucciones-confirm',
                icon: 'swal-instrucciones-icon',
                htmlContainer: 'swal-instrucciones-text'
            },
            didOpen: () => {
                const popup = document.querySelector('swal-instrucciones');
                if (popup) {
                    popup.scrollTop = 0; // Forzar scroll arriba
                }
            }
        });
    }

    verificarIntentos();
    mostrarIntentosRestantes();
    actualizarAccesoPorIntentos();
    controlarAccesoPorIntentos();

    // Sincronizar intentos con examData
    const intentosActuales = obtenerIntentosRestantes();
    let examData = JSON.parse(localStorage.getItem("examData")) || {};
    examData.intentosRestantes = intentosActuales;
    localStorage.setItem("examData", JSON.stringify(examData));

    // Agregar event listeners
    setupEventListeners();
};

// FUNCIÓN PARA SCROLL HACIA ARRIBA
function scrollToTop() {
    setTimeout(() => {
        // Múltiples métodos para máxima compatibilidad
        window.scrollTo({ top: 0 });
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;

        // Para dispositivos móviles iOS/Android
        const scrollableElement = document.scrollingElement || document.documentElement;
        scrollableElement.scrollTop = 0;

        // Método adicional para móviles
        if (window.pageYOffset !== undefined) {
            try {
                window.scroll(0, 0);
            } catch (e) {
                // Fallback silencioso
            }
        }
    }, 150);
}

// CONFIGURACIÓN DE EVENT LISTENERS
function setupEventListeners() {
    // Botón ingresar
    const btnIngresar = document.getElementById("btnIngresar");
    if (btnIngresar) {
        btnIngresar.addEventListener("click", validateAccess);
    }

    // Botón reset admin
    const adminResetBtn = document.getElementById("adminResetBtn");
    if (adminResetBtn) {
        adminResetBtn.addEventListener("click", resetAccess);
    }

    // Menú hamburguesa
    const navBar = document.getElementById("nav-bar");
    if (navBar) {
        navBar.addEventListener("click", showHideMenu);
    }

    // Botón siguiente selección única
    const nextBtn = document.getElementById("nextBtn");
    if (nextBtn) {
        nextBtn.addEventListener("click", function () {
            nextQuestion();
            scrollToTop();
            window.scrollTo(top, 0); // Asegurar que se suba al inicio
        });
    }

    // Botón siguiente desarrollo
    const nextBtnDesarrollo = document.getElementById("nextBtnDesarrollo");
    if (nextBtnDesarrollo) {
        nextBtnDesarrollo.addEventListener("click", function () {
            nextQuestion();
            scrollToTop();
            window.scrollTo(top, 0);
        });
    }

    // Botones práctica
    const btnSiguientePractica1 = document.getElementById("btnSiguientePractica1");
    if (btnSiguientePractica1) {
        btnSiguientePractica1.addEventListener("click", function () {
            nextPracticeSection();
            scrollToTop();
            window.scrollTo(top, 0);
        });
    }

    const btnSiguientePractica2 = document.getElementById("btnSiguientePractica2");
    if (btnSiguientePractica2) {
        btnSiguientePractica2.addEventListener("click", function () {
            nextPracticeSection();
            scrollToTop();
            window.scrollTo(top, 0);
        });
    }

    const btnFinalizarPractica = document.getElementById("btnFinalizarPractica");
    if (btnFinalizarPractica) {
        btnFinalizarPractica.addEventListener("click", function () {
            finalizarPractica();
            scrollToTop();
            window.scrollTo(top, 0);
        });
    }

    // // Botón descargar final
    // const btnDescargarFinal = document.getElementById("btnDescargarFinal");
    // if (btnDescargarFinal) {
    //     btnDescargarFinal.addEventListener("click", function () {
    //         // Marcar que el PDF se descargó
    //         localStorage.setItem("pdfDescargado", "true");
    //         document.getElementById('btnGenerarPDF').click();
    //     });
    // }
    
    // Función para generar la pausa y actualizar el texto del botón
    const esperarConContador = async (segundos, baseTexto, boton) => {
        for (let i = segundos; i > 0; i--) {
            boton.innerText = `${baseTexto} (${i}s)...`;
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    };

    // Botón descargar final
    // --- LÓGICA PARA EL BOTÓN DE RESUMEN FINAL ---
    const btnDescargarFinal = document.getElementById("btnDescargarFinal");

    if (btnDescargarFinal) {
        btnDescargarFinal.addEventListener("click", async function () {
            
            // 1. Bloqueo visual inicial (Igual que el PKA)
            btnDescargarFinal.disabled = true;
            btnDescargarFinal.style.opacity = "0.6";
            btnDescargarFinal.style.cursor = "not-allowed";
            btnDescargarFinal.innerText = "Iniciando generación...";

            try {
                // 3. Espera con contador (Usando tu función esperarConContador)
                // Le damos 5 segundos para que el proceso del PDF termine con calma
                await esperarConContador(5, "Preparando Resumen Teórico", btnDescargarFinal);

                // 2. Ejecución de la descarga (Tu lógica original)
                localStorage.setItem("pdfDescargado", "true");
                const btnGenerar = document.getElementById('btnGenerarPDF');
                if (btnGenerar) {
                    btnGenerar.click();
                }
                
                // 4. Estado final de éxito
                btnDescargarFinal.innerText = "¡Resumen Descargado!";
                btnDescargarFinal.style.backgroundColor = "#28a745"; // El verde sólido
                btnDescargarFinal.style.color = "white";
                
                // El truco clave: Opacidad al 100% para que el verde no se vea "lavado"
                btnDescargarFinal.style.opacity = "0.8"; 
                btnDescargarFinal.style.cursor = "not-allowed";
                
                // Aseguramos que quede deshabilitado permanentemente
                btnDescargarFinal.disabled = true;  

            } catch (error) {
                console.error("Error en el proceso:", error);
                btnDescargarFinal.innerText = "Error en descarga";
                btnDescargarFinal.disabled = false;
                btnDescargarFinal.style.opacity = "1";
            }

            
        });
    } 

    const btnDescargarPracticaPKA = document.getElementById("btnDescargarPracticaPKA");

    if (btnDescargarPracticaPKA) {
        btnDescargarPracticaPKA.addEventListener("click", async function () {
            
            // 1. Bloqueo visual inicial
            btnDescargarPracticaPKA.disabled = true;
            btnDescargarPracticaPKA.style.opacity = "0.6";
            btnDescargarPracticaPKA.style.cursor = "not-allowed";
            
            localStorage.setItem("PDF y PKA descargados", "true");

            const descargarArchivo = (ruta, nombre) => {
                const link = document.createElement("a");
                link.href = ruta;
                link.download = nombre;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            };

            try {

                await esperarConContador(5, "Preparando PDF", btnDescargarPracticaPKA);

                // --- PASO 1: Descargar PDF ---
                btnDescargarPracticaPKA.innerText = "Iniciando PDF...";
                descargarArchivo("documents/Examen_Practica_PacketTracer_INF1004_FundamentosTI.pdf", "Examen_Instrucciones_PacketTracer.pdf");

                // --- PASO 2: Espera con contador para el PKA ---
                // Usamos 5 segundos para asegurar que el navegador no bloquee
                await esperarConContador(5, "Preparando PKA", btnDescargarPracticaPKA);

                // --- PASO 3: Descargar PKA ---
                btnDescargarPracticaPKA.innerText = "Iniciando PKA...";
                descargarArchivo("documents/Examen-Tercera-Parte-Fundamentos-TI.pka", "Examen_Laboratorio_PacketTracer.pka");

                // --- PASO 4: Cuenta atrás final para éxito ---
                await esperarConContador(3, "Finalizando", btnDescargarPracticaPKA);


                // --- PASO 5: Resultado final ---
                btnDescargarPracticaPKA.innerText = "¡Archivos para práctica final descargados!";
                btnDescargarPracticaPKA.style.backgroundColor = "#28a745";
                btnDescargarPracticaPKA.style.color = "white";

                // El truco clave: Opacidad al 100% para que el verde no se vea "lavado"
                btnDescargarPracticaPKA.style.opacity = "0.8"; 
                btnDescargarPracticaPKA.style.cursor = "not-allowed";

                btnDescargarPracticaPKA.disabled = true;
                
            } catch (error) {
                console.error("Error en el proceso:", error);
                btnDescargarPracticaPKA.innerText = "Error en descarga";
                btnDescargarPracticaPKA.disabled = false;
                btnDescargarPracticaPKA.style.opacity = "1";
            }
        });
    }

    // Botón generar PDF del menú
    const btnGenerarPDF = document.getElementById("btnGenerarPDF");
    if (btnGenerarPDF) {
        btnGenerarPDF.addEventListener("click", function () {
            // Marcar que el PDF se descargó
            localStorage.setItem("pdfDescargado", "true");
        });
    }

}

// Función para mostrar instrucciones importantes
function mostrarInstruccionesImportantes() {
    Swal.fire({
        title: 'Instrucciones importantes',
        html: `
      <p>Este exámen es individual y debe completarse sin ayuda.</p>
      <br>
      <ul style="text-align:left;">
        <li>Por favor lea las instrucciones generales detenidamente</li>
        <li>No recargue la página</li>
        <li>No cambie de pestaña o ventana</li>
        <li>Evite cerrar el navegador</li>
        <li>El código de acceso debe consultarlo al docente del curso, es para iniciar su exámen</li>
      </ul>
      <br>
      <b>¿Esta de acuerdo?</b>
    `,
        position: 'top',
        imageUrl: 'images/question.png',
        confirmButtonText: 'Sí estoy de acuerdo',
        cancelButtonText: 'Cancelar',
        showCancelButton: true,
        allowOutsideClick: false,
        allowEscapeKey: false,
        customClass: {
            popup: 'swal-instrucciones',
            title: 'swal-instrucciones-title',
            confirmButton: 'swal-instrucciones-confirm',
            cancelButton: 'swal-instrucciones-cancel',
            icon: 'swal-instrucciones-icon',
            htmlContainer: 'swal-instrucciones-text',
            image: 'swal-instrucciones-image'
        },
        didOpen: () => {
            const popup = document.querySelector('swal-instrucciones');
            if (popup) {
                popup.scrollTop = 0; // Forzar scroll arriba
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            console.log("Usuario aceptó estas instrucciones");
        } else if (result.isDismissed) {
            // El usuario presionó cancelar o cerró el cuadro
            //window.location.href = "https://www.google.com";
        }
    });
}


//Para que no lo vuelva a pedir el código a menos que sea necesario
window.addEventListener("DOMContentLoaded", function () {
    const examData = JSON.parse(localStorage.getItem(EXAM_STORAGE_KEY)) || {};
    const intentosRestantes = examData.intentosRestantes ?? MAX_ATTEMPTS;

    if (localStorage.getItem("parte2Finalizada") === "true") {
        document.getElementById("uniqueSelection").style.display = "none";
        document.getElementById("essay").style.display = "none";
        document.getElementById("practice").style.display = "block";
        initPracticePart();
        // Recuperar la sección actual guardada
        const savedData = JSON.parse(localStorage.getItem("practiceData")) || {};
        const currentSection = savedData.currentSection || 1;
        showPracticeSection(currentSection);
        updatePracticeProgress();
    } else if (localStorage.getItem("parte1Finalizada") === "true") {
        document.getElementById("uniqueSelection").style.display = "none";
        document.getElementById("essay").style.display = "block";
        document.getElementById("practice").style.display = "none";

        // Recupera el índice guardado o empieza en 0 si no existe
        const savedEssayIndex = localStorage.getItem("currentEssayIndex");
        indiceDesarrollo = savedEssayIndex !== null ? parseInt(savedEssayIndex, 10) : 0;

        mostrarPreguntaDesarrollo(indiceDesarrollo);
        cargarPanelLateralDesarrollo();
    } else {
        document.getElementById("uniqueSelection").style.display = "block";
        document.getElementById("essay").style.display = "none";
        document.getElementById("practice").style.display = "none";
    }

    // Si no hay intentos, muestra solo el acceso bloqueado
    if (intentosRestantes <= 0) {
        document.getElementById("access-section").style.display = "block";
        document.getElementById("uniqueSelection").style.display = "none";
        document.getElementById("essay").style.display = "none";
        return;
    }

    // Verificar si está en pantalla finalizada
    if (localStorage.getItem("pantallaFinalizadaActiva") === "true") {
        document.getElementById("access-section").style.display = "none";
        document.getElementById("name-section").style.display = "none";
        document.getElementById("uniqueSelection").style.display = "none";
        document.getElementById("essay").style.display = "none";
        document.getElementById("practice").style.display = "none";
        document.getElementById("mostrarPantallaFinalizada").style.display = "block";
        return;
    }

    // Si ya validó datos y aceptó instrucciones, muestra la parte correspondiente
    if (examData.nombre && examData.cedula && examData.instruccionesAceptadas) {
        document.getElementById("access-section").style.display = "none";
        document.getElementById("name-section").style.display = "block";
        document.getElementById("nav-bar").style.display = "block"; // Mostrar menú hamburguesa
        document.getElementById("begin-timer").style.display = "block"; // Mostrar timer

        // Reiniciar el timer si es necesario
        if (localStorage.getItem("examStarted") === "true") {
            startTimer();
        }

        if (localStorage.getItem("parte2Finalizada") === "true") {
            document.getElementById("uniqueSelection").style.display = "none";
            document.getElementById("essay").style.display = "none";
            document.getElementById("practice").style.display = "block";
            initPracticePart();
            // Recuperar la sección actual guardada
            const savedData = JSON.parse(localStorage.getItem("practiceData")) || {};
            const currentSection = savedData.currentSection || 1;
            showPracticeSection(currentSection);
            updatePracticeProgress();
        } else if (localStorage.getItem("parte1Finalizada") === "true") {
            document.getElementById("uniqueSelection").style.display = "none";
            document.getElementById("essay").style.display = "block";
            document.getElementById("practice").style.display = "none";
            // Solo inicializar preguntas aleatorias si no existen
            const savedQuestions = localStorage.getItem("preguntasDesarrolloSeleccionadas");
            if (!savedQuestions) {
                preguntasDesarrollo = getRandomDevelopmentQuestions();
                localStorage.setItem("preguntasDesarrolloSeleccionadas", JSON.stringify(preguntasDesarrollo));
            } else {
                preguntasDesarrollo = JSON.parse(savedQuestions);
            }
            const savedEssayIndex = localStorage.getItem("currentEssayIndex");
            indiceDesarrollo = savedEssayIndex !== null ? parseInt(savedEssayIndex, 10) : 0;
            mostrarPreguntaDesarrollo(indiceDesarrollo);
            cargarPanelLateralDesarrollo();
        } else {
            document.getElementById("uniqueSelection").style.display = "block";
            document.getElementById("essay").style.display = "none";
            document.getElementById("practice").style.display = "none";
            initUniqueSelection(); //Para que cargue
            renderProgressBar();
        }
    } else {
        // Si no ha validado datos, muestra el acceso
        document.getElementById("access-section").style.display = "block";
        document.getElementById("name-section").style.display = "none";
        document.getElementById("uniqueSelection").style.display = "none";
        document.getElementById("essay").style.display = "none";
        document.getElementById("practice").style.display = "none";
    }
});